In order to compute the code coverage:

- Build the test application: make
- Run the test suite:         ch
- Compute the code coverage:  make gcov
- Clear everything:           make clean
